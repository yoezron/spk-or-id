<div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-5 d-none d-lg-block bg-register-image "></div>
                <div class="col-lg-7">
                    <div class="p-5">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Bergabung Bersama Kami!</h1>
                        </div>
                        <form class="user" method="post" action="<?= base_url('auth'); ?>/registration">
                            <div class="form-group row">
                                <div class="form-group col-lg-12">
                                    <input type="text" class="form-control form-control-user" id="name" name="name" placeholder="Nama Lengkap" value="<?= set_value('name'); ?>">
                                    <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="form-group col-sm-6">
                                    <select class="form-group" id="gender" name="gender" value="<?= $user['gender']; ?>">
                                        <option selected disabled>Jenis Kelamin</option>
                                        <option>laki-laki</option>
                                        <option>perempuan</option>
                                    </select>
                                </div>
                                <?= form_error('gender', '<small class="text-danger pl-3">', '</small>'); ?>
                                <div class="form-group col-sm-6">
                                    <select class="form-group" id="status" name="status" value="<?= $user['status']; ?>">
                                        <option selected disabled>Status Kepegawaian</option>
                                        <option>Dosen PNS</option>
                                        <option>PPPK</option>
                                        <option>Dosen Tetap Non PNS</option>
                                        <option>Dosen Tidak Tetap/Honorer</option>
                                        <option>Dosen Kontrak</option>
                                        <option>Tendik PNS</option>
                                        <option>Tendik Tetap Non PNS</option>
                                        <option>Tendik Tidak Tetap/Honorer</option>
                                        <option>Tendik Kontrak</option>
                                        <option>Outsourcing</option>
                                    </select>
                                </div>
                                <?= form_error('status', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control form-control-user" id="email" name="email" placeholder="Alamat Email" value="<?= set_value('email');  ?>">
                                <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id="kampus" name="kampus" placeholder="Asal Kampus" value="<?= set_value('kampus');  ?>">
                            </div>
                            <?= form_error('kampus', '<small class="text-danger pl-3">', '</small>'); ?>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id="telp" name="telp" placeholder="Nomor Whatsapp" value="<?= set_value('telp');  ?>">
                            </div>
                            <?= form_error('telp', '<small class="text-danger pl-3">', '</small>'); ?>

                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="password" class="form-control form-control-user" id="password1" name="password1" placeholder="Password">
                                    <?= form_error('password1', '<small class="text-danger pl-3">', '</small>'); ?>
                                </div>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control form-control-user" id="password2" name="password2" placeholder="Ulangi Password">
                                </div>
                            </div>
                            <!-- Checkbox Term and Condition -->
                            <div class="form-group">
                                <div class="custom-control custom-checkbox small">
                                    <input type="checkbox" class="custom-control-input" id="agree_terms" name="agree_terms">
                                    <label class="custom-control-label" for="agree_terms">Dengan mendaftar saya bersedia mematuhi AD/ART Serikat Pekerja Kampus</label>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-user btn-block">
                                Registrasi Akun
                            </button>
                            <div class="text-center">
                                <a class="small" href="<?= base_url('auth/forgotpassword') ?>">Lupa Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="<?= base_url('auth')  ?>">Sudah punya akun? Login!</a>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>