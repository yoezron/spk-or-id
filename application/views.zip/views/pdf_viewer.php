<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anggaran Dasar & Anggaran Rumah Tangga</title>
    <!-- Anda dapat menambahkan CSS tambahan di sini jika diperlukan -->
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h1 class="h3 mb-4 text-gray-800">Anggaran Dasar & Anggaran Rumah Tangga</h1>
                <div class="card">
                    <div class="card-body">
                        <iframe src="<?= base_url('assets/AD-ART SPK.pdf'); ?>" style="width: 100%; height: 600px; border: none;"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>